# Setup Security Tools

This package installs OWASP ZAP, Gitleaks, and TruffleHog on a Windows machine using Chocolatey and pip.

## Usage

To use this package, install it locally and run the command:

```bash
setup-security-tools
